from django.apps import AppConfig


class DonationsConfig(AppConfig):
    name = 'donations'
