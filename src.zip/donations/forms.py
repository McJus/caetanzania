from django import forms
from django.forms import ModelForm
from .models import Donation

class DonationForm(forms.ModelForm):

    class Meta:
        model = Donation
        fields = ['donate_type','amount', 'purpose',"cc_number","cc_expiry","cc_code"]
        widgets = {
            'amount': forms.NumberInput(attrs={'class': 'myfieldclass', 'placeholder':'enter amount'}),
            'purpose':forms.Select()
           
        }
        exclude =['user']